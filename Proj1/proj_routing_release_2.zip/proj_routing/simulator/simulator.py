#!/usr/bin/env python

# Start the simulator!
import sim.boot
sim.boot.main()
